<template>
  <div style="height: 100%;padding: 0; padding-top: 13px;padding-bottom: 13px;    background-color: #7d859738;">
    <div>
      <v-container class="damageContainer">
        <v-row>
          <v-col class="damageSelect" style=" padding-left: 62px; padding-right: 62px; " cols="12" sm="6" md="6">
            <v-select s tyle="cursor: pointer !important;" solo :items="profile_groupe" item-text="name" item-value="id"
              v-model="profile_groupe_id" label="Equipment groups :" :disabled="disabled"
              @change="changeProfile_groupeSELECT" ref="profileGroupSelect"></v-select>
          </v-col>
          <v-col class="damageSelect" style=" padding-left: 62px; padding-right: 62px; " cols="12" sm="6" md="6">
            <v-select ref="profileGroupSelect_2" style="cursor: pointer !important;" solo :items="equipmentsFiltre" item-text="name"
              item-value="id" v-model="equipments_id" label="Equipment :" @change="changeEquipmentsFiltreSELECT"
              :disabled="disabledEquipmentsFiltre"></v-select>
          </v-col>
        </v-row>




        <v-dialog v-model="dialog" persistent max-width="600px">
          <v-card>
            <v-toolbar dark style="background-color: rgb(21, 40, 85);">
              <v-toolbar-title>CHECKLIT VALIDATION</v-toolbar-title>
            </v-toolbar>
            <v-card-title class="text-h5">
              Click <span style="font-weight: 900;color:rgb(21, 40, 85)">YES</span> if you want to validate your
              checklist:
            </v-card-title>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn style="    font-weight: 900;" color="white" @click="cancel"> No </v-btn>
              <v-btn style="   background-color: rgb(73 114 209); font-weight: 900;" @click="dialog = false"> Yes
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>



        <v-dialog v-model="cmt_actual_pic_edit" persistent max-width="600px">
          <v-card>
            <v-toolbar dark style="background-color: rgb(21, 40, 85);">
              <v-toolbar-title>ALREADY SELECTED DEFECT SUB TYPE !</v-toolbar-title>
            </v-toolbar>
            <v-card-title class="text-h5">
              The sub defect type is already selected.<br> <span
                style="margin-top: 45px; font-weight: 700; color: rgb(81 101 255); ">PLEASE SELECT THE NEXT ACTION
                :</span>
            </v-card-title>
            <v-card-text class="font-weight-bold"></v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="white" @click="cmt_actual_pic_edit = false"> Cancel </v-btn>
              <v-btn style=" font-weight: 700; color: white; " color="rgb(21, 40, 85)"
                @click="cmt_actual_pic_edit = false; valider_3(selected_sub_Defect)"> UNSELECT </v-btn>
              <v-btn style=" font-weight: 700; color: white; " color="rgb(105 142 229)"
                @click="cmt_actual_pic_edit = false; techDefects_withCmt(selected_sub_Defect)"> EDIT </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="cmt_actual_pic_delete" persistent max-width="600px">
          <v-card>
            <v-toolbar dark style="background-color: rgb(21, 40, 85);">
              <v-toolbar-title>Warning !</v-toolbar-title>
            </v-toolbar>
            <v-card-title class="text-h5">
              Are you sure to delete this picture ?
            </v-card-title>
            <v-card-text class="font-weight-bold"></v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="white" @click="cmt_actual_pic_delete = false"> No </v-btn>
              <v-btn color="primary" @click="deleteImage()"> Yes </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="dialogValide" persistent max-width="600px">
          <v-card>
            <v-toolbar dark style="background-color: rgb(21, 40, 85);">
              <v-toolbar-title>CHECKLIT VALIDATION</v-toolbar-title>
            </v-toolbar>
            <v-card-title class="text-h5">
              Click <span style="font-weight: 900;color:rgb(21, 40, 85)">YES</span> if you want to validate your
              checklist:
            </v-card-title>
            <v-card-text class="font-weight-bold"></v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="white" @click="cancelvalide()"> No </v-btn>
              <v-btn color="rgb(21, 40, 85)" @click="valider()"> Yes </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="dialogValideDamage" persistent max-width="600px">
          <v-card>
            <v-toolbar dark style="background-color: rgb(21, 40, 85);">
              <v-toolbar-title style="font-weight: 900">CHECKLIT VALIDATION</v-toolbar-title>
            </v-toolbar>
            <v-card-title class="text-h5">
              Click <span style="margin-left:6px; margin-right:6px; font-weight: 900;color:rgb(144 177 255)">YES</span>
              if you want to validate your checklist:
            </v-card-title>
            <v-card-text class="font-weight-bold"></v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="white" @click="dialogValideDamage = false" style=" font-weight: 900;">
                No
              </v-btn>
              <v-btn style="color:white; background-color: rgb(73 114 209); font-weight: 900;"
                @click="validerDamages()"> Yes </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="driver_comment_dialog" persistent max-width="700">
          <v-card>
            <v-card-title class="text-h5  lighten-1 white--text" style="background-color: rgb(21, 40, 85);">
              <v-icon
                style=" font-size: 51px; margin-left: -12px; margin-right: 9px; margin-bottom: 5px; color: white; ">{{
                  selectedDefect?.icon }}</v-icon>
              {{ selectedDefect?.name }} DEFECT TYPES:
            </v-card-title>
            <v-spacer></v-spacer>
            <v-card-text class="pa-4 black--text" style="   font-size: 30px; font-weight: 900;">
              Please select a defect specification :
              <v-row class="subType  m-0 p-0">
                <v-col style="padding: 0;" class=" m-0 p-0" cols="6"
                v-for="(item,i) in defectList.filter((t) => t.name != 'Other & comment').reverse()"
                :key="i">
                  <span v-if="item.damage == null"
                    @click="item?.name != 'Other & comment' && isChecked(item) ? cmt_actual_pic_edit_open(item) : techDefects_withCmt(item)"
                    :class="item?.name != 'Other & comment' && isChecked(item) ? 'checked' : ''" class="sub_box m-0 p-0
                  ">{{ item.name }}</span>
                  <span v-else-if="item?.name != 'Other & comment' && item.damage.status == 'on progress'"
                    @click="defectedFunction(item)" class="sub_box progress m-0 p-0">{{ item.name }}</span>
                  <span v-else-if="item?.name != 'Other & comment' && item.damage.status == 'resolved'"
                    @click="resolvedFunction(item)" class="sub_box resolved m-0 p-0">{{ item.name }}</span>
                </v-col>



                <v-col style="padding: 0;" class=" m-0 p-0" cols="6"
                  v-for="(item,i) in defectList.filter((t) => t.name == 'Other & comment')"
                  :key="i"
                  >
                  <span v-if="item.damage == null"
                    @click="item?.name != 'Other & comment' && isChecked(item) ? cmt_actual_pic_edit_open(item) : techDefects_withCmt(item)"
                    :class="item?.name != 'Other & comment' && isChecked(item) ? 'checked' : ''" class="sub_box m-0 p-0
                  ">{{ item.name }}</span>
                  <span v-else-if="item?.name != 'Other & comment' && item.damage.status == 'on progress'"
                    @click="defectedFunction(item)" class="sub_box progress m-0 p-0">{{ item.name }}</span>
                  <span v-else-if="item?.name != 'Other & comment' && item.damage.status == 'resolved'"
                    @click="resolvedFunction(item)" class="sub_box resolved m-0 p-0">{{ item.name }}</span>
                </v-col>
              </v-row>
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn style="    font-weight: 900;" color="#fff " @click="valider_cmt_first_cancel()">
                Cancel
              </v-btn>
              <v-btn
                style="background-color: rgb(68 96 163);border-color: rgb(21, 40, 85);color: white;font-weight: 900;width: 143px;font-size: 18px;"
                class="mr-2" color="rgb(21, 40, 85)" @click="valider_cmt_first_confirm()">
                Confirm
              </v-btn>

            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="damageTech_cmt_fullscreen_img" max-width="800px">
          <template v-slot:default="{ isActive }">
            <v-card rounded="lg">
              <v-card-title class="d-flex justify-space-between align-center">
                <div class="text-h5 text-medium-emphasis ps-2">
                  {{ selected_sub_Defect?.name }} Picture :
                </div>
                <v-spacer></v-spacer>
                <v-btn style="    font-weight: 900;color:white" color="red " @click="cmt_actual_pic_delete = true">
                  DELETE
                </v-btn>
                <v-btn style=" margin-left:8px  ;   font-weight: 900;color:white" color="green "
                  @click="downloadImage(cmt_actual_pic)">
                  DOWNLOAD
                </v-btn>
                <v-btn style="    background-color: rgb(229 229 229);
                                  border-color: rgb(201 25 25);
                                  margin-left: 8px;
                                  /* font-weight: 900; */
                                  margin-right: 14px;
                                  font-size: 31px;
                                  border-radius: 46px;
                                  /* width: 16px !important; */
                                  color: #913333;" @click="damageTech_cmt_fullscreen_img = false">
                  <v-icon style="    color: #b04242;
                                    font-size: 37px;
                                    margin-top: 2px;
                                ">mdi-close-circle</v-icon>
                </v-btn>
              </v-card-title>
              <v-divider class="mb-4"></v-divider>
              <v-card-text class="pic_full_screen">
                <div>
                  <img :src="getImageUrl(cmt_actual_pic)" alt="">
                </div>
              </v-card-text>
            </v-card>
          </template>
        </v-dialog>
        <v-dialog v-model="damageTech_cmt" persistent max-width="800px">
          <v-card>
            <v-card-title class="text-h5 lighten-1 white--text" style="background-color: rgb(79 102 156);">
              <v-icon style=" font-size: 40px;
              margin-left: -12px;
              margin-right: 9px;
              margin-bottom: 5px;
              color: white; ">{{ selected_sub_Defect?.damageType_master?.icon }}</v-icon>
              Declare item : {{ selected_sub_Defect?.name }}
            </v-card-title>
            <v-spacer></v-spacer>

            <v-card-text class="pa-4 black--text" style="font-size: 19px; font-weight: 900; ">
              <span style="font-size: 19px; font-weight: 900; margin-bottom: 17px; display: inline-block;">Add details
                (comment/pictures) :</span>
              <v-textarea 
              :placeholder="'I have found that the '+selected_sub_Defect?.name+' is/are defective..'"
              label="Defect comment.." v-model="damageTech_cmt_payload.comment" name="input-7-1"
                variant="outlined" style="BACKGROUND-COLOR:#cacaca !important;" class="sub_comment_text"></v-textarea>
              <div cols="12" md="12" class="cmt_pic_background">
                <span class="images_pannel">
                  <img v-for="(pic,i) in damageTech_cmt_payload.files" :key="i" @click="imagefullScreen(pic)" :src="getImageUrl(pic)"
                    alt="">

                </span>
                <span class="add_button" @click="triggerUpload">
                  <input type="file" ref="fileInput" style="display: none" @change="handleFileChange" />
                  <v-icon size="45px" class="">mdi-plus</v-icon>
                </span>

              </div>
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn style="    font-weight: 900;" color="#fff " @click="techDefects_withCmt_close">
                Cancel
              </v-btn>
              <v-btn
                v-if="Data.filter((r) => r.damage_type_id == selected_sub_Defect?.id).length > 0 && selectedDefect?.damageTypes.length == 1 && selected_sub_Defect?.damage_type_master.name == 'OTHER'"
                style="width:250px; color:white   ;    font-weight: 900; background-color: rgb(73 114 209);"
                class="mr-2" @click="valider_3(selected_sub_Defect)">
                Not-Defective
              </v-btn>
              <v-btn
                :disabled="selected_sub_Defect?.damage_type_master.name == 'OTHER' && damageTech_cmt_payload.comment == ''"
                style="width: 250px; color:white   ;   font-weight: 900;" class="mr-2" color="#d43737"
                @click="techDefects_withCmt_confirm()">
                DEFECTIVE
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="resolvedDialoge" persistent max-width="800px">
          <v-card>
            <v-card-title class="text-h5 lighten-1 white--text" style="background-color: rgb(79 102 156);">
              <v-icon style=" font-size: 40px;
              margin-left: -12px;
              margin-right: 9px;
              margin-bottom: 5px;
              color: white; ">{{ resolveditem[0]?.damageType_master?.icon }}</v-icon>
              RESOLVED ITEM : {{ resolveditem[0]?.name }}
            </v-card-title>
            <v-spacer></v-spacer>

            <v-card-text class="pa-4 black--text" style="    font-weight: 900;">
              Warning this is a resolved item, are you sure you want to turn it
              not-defective or defective ?
              <v-textarea label="Defect comment.." v-model="damageTech_cmt_payload.comment" name="input-7-1"
                variant="outlined" style="BACKGROUND-COLOR:#cacaca !important; margin-top: 15px ;"
                class="sub_comment_text"></v-textarea>
              <div cols="12" md="12" class="cmt_pic_background">
                <span class="images_pannel">
                  <img v-for="(pic,i) in damageTech_cmt_payload.files" :key="i" @click="imagefullScreen(pic)" :src="getImageUrl(pic)"
                    alt="">

                </span>
                <span class="add_button" @click="triggerUpload">
                  <input type="file" ref="fileInput" style="display: none" @change="handleFileChange" />
                  <v-icon size="45px" class="">mdi-plus</v-icon>
                </span>

              </div>
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn style="    font-weight: 900;" color="#fff " @click="resolvedDialoge = false">
                Cancel
              </v-btn>
              <v-btn :disabled="damageTech_cmt_payload.comment == ''"
                style="width:250px; color:white   ;   font-weight: 900;" class="mr-2" color="#d43737" @click="revert">
                Defective
              </v-btn>
              <v-btn :disabled="damageTech_cmt_payload.comment == ''"
                style="width:250px; color:white   ;    font-weight: 900; background-color: rgb(73 114 209);"
                class="mr-2" @click="confirmed">
                Not-Defective
              </v-btn>

            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-dialog v-model="defectedDialoge" persistent max-width="800px">
          <v-card>
            <v-card-title class="text-h5 red lighten-1 white--text">
              <v-icon style=" font-size: 40px;
              margin-left: -12px;
              margin-right: 9px;
              margin-bottom: 5px;
              color: white; ">{{ resolveditem[0]?.damageType_master?.icon }}</v-icon>
              DEFECTIVE ITEM : {{ resolveditem[0]?.name }}
            </v-card-title>
            <v-spacer></v-spacer>

            <v-card-text class="pa-4 black--text" style="    font-weight: 900;">
              This is a defective item, are you sure you want to turn it
              not-defective ?
              <v-textarea label="Defect comment.." v-model="damageTech_cmt_payload.comment" name="input-7-1"
                variant="outlined" style="BACKGROUND-COLOR:#cacaca !important;  margin-top: 15px ;"
                class="sub_comment_text"></v-textarea>
              <div cols="12" md="12" class="cmt_pic_background">
                <span class="images_pannel">
                  <img v-for="(pic,i) in damageTech_cmt_payload.files" :key="i" @click="imagefullScreen(pic)" :src="getImageUrl(pic)"
                    alt="">

                </span>
                <span class="add_button" @click="triggerUpload">
                  <input type="file" ref="fileInput" style="display: none" @change="handleFileChange" />
                  <v-icon size="45px" class="">mdi-plus</v-icon>
                </span>

              </div>
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="#fff" @click="defectedDialoge = false">
                Cancel
              </v-btn>

              <v-btn :disabled="damageTech_cmt_payload.comment == ''"
                style="width:250px; color:white   ;    font-weight: 900; background-color: rgb(73 114 209);"
                class="mr-2" color="#76ba99" @click="confirmed">
                Not-Defective
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <v-container>
          <v-row>
            <v-col cols="12" class="TECpanell">
              <v-row>
                <v-col cols="6" class="d-flex justify-center" style="
                    margin-top: 0 !important;
                    padding: 0;
                    /* background-color: #25204f; */
                    max-width: 50% !important;
                    text-align: center;
                    margin: 0 auto;
                    color: white !important;
                    border-bottom-left-radius: 30px;
                    border-bottom-right-radius: 30px;
                    margin-bottom: 20px;
                    border: 1px solid black;
                    border-left: none;
                    border-right: none;
                    border-top: none;
                ">
                  <span>TECH DEFECTS : </span>
                  <span v-if="damageTypesTEC.length > 0" class="red--text ml-3">D ({{ this.countDefectsTEC }})</span>
                  <span v-if="damageTypesTEC.length > 0" class="warning--text ml-1"> R ({{ this.countResolvedTEC
                  }})</span>
                </v-col>
              </v-row>

              <v-col cols="12" sm="12" class="scroll">
                <v-list flat>
                  <v-list-item-group name="TEC" class="TEC" v-model="modelTEC" multiple color="#fff">
                    <div class="hamzatec technique-Fayssal">
                      <v-list-item v-for="(item, i) in damageTypesTEC" :key="i" class="item" two-line
                        :class="MasterIsChecked(item) ? 'defect_active' : 'defect_intact'"
                        @click="valider_cmt_first(item, i)" style="    border-bottom: 1px solid rgb(37 32 79 / 76%);
                                    padding-bottom: 9px;
                                    border-bottom-left-radius: 24px;
                                    border-bottom-right-radius: 24px;">
                        <v-list-item-content class="item-content">
                          <span v-if="item.important == false">
                            <v-list-item-title name="damageTypesTEC" class="itemName">
                              <v-icon>{{ item.icon }}</v-icon>
                            </v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle">
                              <span>{{
                                item.name }}</span>

                            </v-list-item-subtitle>
                          </span>
                          <span v-else-if="item.important == true">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #76ba99"></v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle" style="
                                color: rgb(0, 171, 88);
                                font-weight: bolder !important;
                                width: 170px !important;
                              ">{{ item.name }}</v-list-item-subtitle>
                          </span>
                        </v-list-item-content>
                        <span class="defect_details_counts">
                          <span>D : {{ item.countDefective }}</span>
                          <span>R : {{ item.countResolved }}</span>
                        </span>
                      </v-list-item>
                    </div>
                  </v-list-item-group>
                </v-list>
              </v-col>
            </v-col>
            <v-col cols="12" class="ITpanell">
              <v-row>
                <v-col cols="6" class="d-flex justify-center" style="
                    margin-top: 0 !important;
                    padding: 0;
                    /* background-color: #25204f; */
                    max-width: 50% !important;
                    text-align: center;
                    margin: 0 auto;
                    color: white !important;
                    border-bottom-left-radius: 30px;
                    border-bottom-right-radius: 30px;
                    margin-bottom: 20px;
                    border: 1px solid black;
                    border-left: none;
                    border-right: none;
                    border-top: none;
                ">
                  <span>IT DEFECTS : </span>
                  <span v-if="damageTypesIT.length > 0" class="red--text ml-3">D ({{ this.countDefects }})</span>
                  <span v-if="damageTypesIT.length > 0" class="warning--text ml-1"> R ({{ this.countResolved }})</span>
                </v-col>
              </v-row>

              <v-col cols="12" sm="12" class="scrollIT">
                <v-list flat>
                  <v-list-item-group name="it" v-model="modelIT" multiple color="#fff" class="ITcol TEC">
                    <div class="hamzatec">
                      <v-list-item
                        v-for="(item, i) in damageTypesIT.filter(e => e.name != 'OTHER' && e.damage_type_id == null)"
                        :key="i" class="item" two-line :class="{
                          defect_active: isChecked(item) || item.damage?.status === 'on progress',
                          defect_intact: !(isChecked(item) || item.damage?.status === 'on progress'),
                          resolved: item.damage?.status === 'resolved',
                        }" @click="item.damage == null ? valider(item, i) :
                          item.damage.status == 'on progress' ? defectedFunction(item, i) :
                            resolvedFunction(item, i)

                          ">
                        <v-list-item-content v-if="true" class="item-content">
                          <span v-if="item.important == false">
                            <v-list-item-title name="damageTypesTEC" class="itemName">
                              <v-icon>{{ item.icon }}</v-icon>
                            </v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle">
                              <span>{{ item.name }}</span>
                            </v-list-item-subtitle>
                          </span>
                          <span v-else-if="item.important == true">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #76ba99"></v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle" style="
                                color: rgb(0, 171, 88);
                                font-weight: bolder !important;
                              ">{{ item.name }}</v-list-item-subtitle>
                          </span>
                        </v-list-item-content>




                        <v-list-item-content v-else-if="item.damage.status == 'resolved'" class="item-content resolved">
                          <span v-if="item.important == false">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #ff8f56"></v-list-item-title>
                            <v-list-item-subtitle style="color: #ff8f56" class="itemSubtitle">{{ item.name
                            }}</v-list-item-subtitle>
                          </span>
                          <span v-else-if="item.important == true">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #ff8f56"></v-list-item-title>
                            <v-list-item-subtitle style="
                                color: #ff8f56;
                                font-weight: bolder !important;
                              " class="itemSubtitle">{{ item.name }}</v-list-item-subtitle>
                          </span>
                        </v-list-item-content>
                        <v-list-item-content v-else-if="item.damage.status == 'on progress'"
                          class="item-content defects">
                          <span v-if="item.important == false">

                            <v-list-item-title name="damageTypesTEC" class="itemName">
                              <v-icon>{{ item.icon }}</v-icon>
                            </v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle">
                              <span>{{ item.name }}</span>
                            </v-list-item-subtitle>

                          </span>
                          <span v-if="item.important == true">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #f54"></v-list-item-title>
                            <v-list-item-subtitle style="
                                color: #f54;
                                font-weight: bolder !important;
                              " class="itemSubtitle">{{ item.name }}</v-list-item-subtitle>
                          </span>
                        </v-list-item-content>
                        <span class="defect_details_counts" v-if="item.name == 'OTHER'">
                          <span>T : {{ item.damageTypes.length - 1 }}</span>
                          <span>D : {{ item.countDefective }}</span>
                          <span>R : {{ item.countResolved }}</span>
                        </span>
                      </v-list-item>
                      <v-list-item
                        v-for="(item, i) in damageTypesIT.filter(e => e.name == 'OTHER' && e.damage_type_id == null)"
                        :key="i" class="item" two-line
                        :class="MasterIsChecked(item) ? 'defect_active' : 'defect_intact'"
                        @click="valider_cmt_first(item, i)" style="    border-bottom: 1px solid #25204f1a;
                                    padding-bottom: 9px;
                                    border-bottom-left-radius: 24px;
                                    border-bottom-right-radius: 24px;">
                        <v-list-item-content class="item-content">
                          <span v-if="item.important == false">
                            <v-list-item-title name="damageTypesTEC" class="itemName">
                              <v-icon>{{ item.icon }}</v-icon>
                            </v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle">
                              <span>{{
                                item.name }}</span>

                            </v-list-item-subtitle>
                          </span>
                          <span v-else-if="item.important == true">
                            <v-list-item-title name="damageTypesTEC" class="itemName"
                              style="background-color: #76ba99"></v-list-item-title>
                            <v-list-item-subtitle class="itemSubtitle" style="
                                color: rgb(0, 171, 88);
                                font-weight: bolder !important;
                                width: 170px !important;
                              ">{{ item.name }}</v-list-item-subtitle>
                          </span>
                        </v-list-item-content>
                        <span class="defect_details_counts">
                          <span>T : {{ item.damageTypes.length }}</span>
                          <span>D : {{ item.countDefective }}</span>
                          <span>R : {{ item.countResolved }}</span>
                        </span>
                      </v-list-item>
                    </div>
                  </v-list-item-group>
                </v-list>
              </v-col>
            </v-col>
          </v-row>
          <v-row class="d-flex justify-center">
            <v-col cols="4">
              <v-sheet color="#d43737" elevation="1" height="20" width="20" rounded></v-sheet>
              Defective
            </v-col>
            <v-col cols="4">
              <v-sheet color="#fb8500" elevation="1" height="20" width="20" rounded></v-sheet>
              Resolved
            </v-col>
            <v-col cols="3">
              <v-sheet color="rgb(21, 40, 85)" elevation="1" height="20" width="20" rounded></v-sheet>
              Not-Defective
            </v-col>
          </v-row>
        </v-container>
        <v-container>
          <v-row>
            <v-col class="d-flex justify-center" cols="12">
              <v-btn
              
              v-if="
              countResolvedTEC>0 ||
              countResolved>0 
              
              "
              depressed style="font-weight: 900; background-color: rgb(73 114 209); color: white; width: 250px;"
                color="" :disabled="true" >
                STILL {{ countResolvedTEC+countResolved }} RESOLVED DEFECTS !
              </v-btn>
              <v-btn 
              v-else
              depressed style="font-weight: 900; background-color: rgb(73 114 209); color: white; width: 250px;"
                color="" :disabled="disabled" @click="test()">
                FINISH CHECKLIST
              </v-btn>
            </v-col>
            <v-col class="d-flex justify-center" cols="12"
              style="user-select: none;margin: 0; padding: 0; margin-top: -9px; color: #00000054;">
              <span style="display: block;">Note: Clicking 'Finish' will submit your checklist. Please review all items
                before
                submitting.</span>
            </v-col>
          </v-row>
        </v-container>
      </v-container>
    </div>

    <LoadingPage v-if="LoadingPage == true" />
  </div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import { defineAsyncComponent } from "vue";
import swal from "sweetalert";
//import LoadingPage from "../LoadingPage.vue";
const LoadingPage = defineAsyncComponent(() => import("../LoadingPage.vue"));
import moment from "moment/src/moment";

export default {
  components: {
    LoadingPage,
  },
  data: () => ({
    countMineId: 0,
    cmt_actual_pic_edit: false,
    cmt_actual_pic_delete: false,
    cmt_actual_pic: null,
    defectList: [],
    damageTech_cmt_payload: {
      comment: "",
      files: []
    },
    damageTech_cmt_fullscreen_img: false,
    damageTech_cmt: false,
    selected_sub_Defect: null,
    selectedDefect: null,
    driver_comment_dialog: false,
    userFiltre: [],
    disabled: false,
    LoadingPage: false,
    resolvedDialoge: false,
    defectedDialoge: false,
    dialogLogin: false,
    damageTypesIT: [],
    damageTypesTEC: [],
    modelDamageIT: [],
    modelDamageTEC: [],
    confirmedDamageTEC: [],
    confirmedDamageIT: [],
    equipmentsFiltre: [],
    Data: [],
    Data_2: [],
    damageCourent: {
      declaredBy_id: null,
      equipment_id: null,
      damage_type_id: null,
      shift: "",
    },
    damage_type_id: null,
    modelIT_id_Courent: null,
    modelTEC_id_Courent: null,
    profile_groupe: [],
    equipments: [],
    damagesend: [],
    modelIT: [],
    modelTEC: [],
    department: [],
    departmentIT: {
      id: null,
      name: "",
      email: "",
      created_at: "",
      updated_at: "",
    },
    departmentTEC: {
      id: null,
      name: "",
      email: "",
      created_at: "",
      updated_at: "",
    },
    departmentOP: {
      id: null,
      name: "",
      email: "",
      created_at: "",
      updated_at: "",
    },
    DamageSelect: {
      id: null,
      driver_comment: "",
      status: "",
      description: "",
      declaredBy_id: null,
      declaredAt: "",
      confirmedBy_id: null,
      confirmedAt: null,
      closedBy_id: null,
      closedAt: null,
      rejectedBy_id: null,
      rejectedAt: null,
      rejectedTimes: null,
      equipment_id: null,
      damage_type_id: null,
      created_at: "",
      updated_at: "",
      declared_by: {
        id: null,
        username: "",
        lastName: "",
        firstName: "",
        email: "",
        phoneNumber: "",
        fonction_id: null,
        created_at: "",
        updated_at: "",
        fonction: {
          id: null,
          name: "",
          department_id: null,
          created_at: "",
          updated_at: "",
          department: {
            id: null,
            name: "",
            created_at: "",
            updated_at: "",
          },
        },
      },
      confirmed_by: null,
      closed_by: null,
      rejected_by: null,
      equipment: {
        id: null,
        name: "",
        profile_group_id: null,
        created_at: "",
        updated_at: "",
        profile_group: {
          id: null,
          name: "",
          department_id: null,
          created_at: "",
          updated_at: "",
          department: {
            id: null,
            name: "",
            created_at: "",
            updated_at: "",
          },
        },
      },
      damage_type: {
        id: null,
        name: "",
        profile_group_id: null,
        department_id: null,
        created_at: "",
        updated_at: "",
        profile_group: {
          id: null,
          name: "",
          department_id: null,
          created_at: "",
          updated_at: "",
          department: {
            id: null,
            name: "",
            created_at: "",
            updated_at: "",
          },
        },
        department: {
          id: null,
          name: "",
          created_at: "",
          updated_at: "",
        },
      },
      photos: [
        {
          id: null,
          description: null,
          filename: "",
          damage_id: null,
          created_at: "",
          updated_at: "",
        },
      ],
    },
    presenceCheck: {
      user_id: 0,
      equipment_id: 0,
      validation_presence_At: "",
    },
    confirmDamage: {
      id: null,
      confirmedBy_id: null,
      resolveDescription: "",
    },
    closeDamage: {
      id: null,
      closedBy_id: null,
    },
    revertDamage: {
      id: null,
      rejectedBy_id: null,
      rejectedDescription: "",
    },
    resolveditem: [],
    defecteditem: [],
    defectsChange: {
      item: [],
      damagetypeOld: [],
      statusOld: null,
      statusNew: "",
    },
    EmailModel: {
      payload: {
        Equipment: "",
        EquipmentGroupe: "",
        Department: "",
        Defects: [],
        Status: "on progress",
        DriverOut: "",
        DeclaredBy: "",
        DeclaredAt: "",
      },
      status: "",
      email: "",
      department: [],
    },
    EmailModelTEC: {
      payload: {
        Equipment: "",
        EquipmentGroupe: "",
        Department: "",
        Defects: [],
        Status: "on progress",
        DriverOut: "",
        DeclaredBy: "",
        DeclaredAt: "",
      },
      status: "",
      email: "",
      department: [],
    },
    a: [],
    b: [],
    listdepartmentIT: [],
    listDefectsNamesIT: [],
    listdepartmentTEC: [],
    listDefectsNamesTEC: [],
    listDefectsNamesTECFinal: [],
    listDefectsNamesITFinal: [],
    listDefectsChange: [],
    DamageTypeByEquipmentID: [],
    DamagesMergedWithDamageTypes: [],
    damageSelect: [],
    isvalide: false,
    equipments_id: "",
    dialog: false,
    dialogValide: false,
    profile_groupe_id: null,
    disabledEquipmentsFiltre: true,
    dialogValideDamage: false,
    countDefects: 0,
    countResolved: 0,
    countDefectsTEC: 0,
    countResolvedTEC: 0,
    countImportantTEC: 0,
    countImportantIT: 0,
    EquipmentName: "",
  }),
  mounted() {
    document.title = "Checklist";
  },
  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Item" : "Edit Item";
    },
    ...mapGetters([
      "getUsers",
      "getdamageTypes",
      "getprofilegroups",
      "getequipments",
      "getDamageTypeByEquipmentID",
      "getdamage",
      "getEquipmentDamagesMergedWithDamageTypes",
      "getdepartements",
      "getUserActive",
    ]),
  },
  watch: {
    dialog(val) {
      val || this.cancel();
    },
    dialogDelete(val) {
      val || this.closeDelete();
    },
  },
  created() {
    this.initialize();
  },
  methods: {
    openProfileGroupSelect() {
      if (this.$refs.profileGroupSelect) {
        this.$refs.profileGroupSelect.menu = true;
        if (typeof this.$refs.profileGroupSelect.activateMenu === 'function') {
          this.$refs.profileGroupSelect.activateMenu();
        }
      }
    },
    openProfileGroupSelect_2() {
      if (this.$refs.profileGroupSelect_2) {
        this.$refs.profileGroupSelect_2.menu = true;
        if (typeof this.$refs.profileGroupSelect_2.activateMenu === 'function') {
          this.$refs.profileGroupSelect_2.activateMenu();
        }
      }
    },
    cmt_actual_pic_edit_open(item) {
      this.selected_sub_Defect = item;

      this.cmt_actual_pic_edit = true;
    },
    deleteImage() {
      this.damageTech_cmt_payload.files = this.damageTech_cmt_payload.files.filter((e) => {
        return e.name != this.cmt_actual_pic.name;
      });
      this.cmt_actual_pic_delete = false;
      this.damageTech_cmt_fullscreen_img = false;
    },
    downloadImage(file) {
      if (!file) return;

      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name || 'download.jpg';
      a.click();
      URL.revokeObjectURL(url); // Clean up
    },
    getImageUrl(file) {
      if (file)
        return URL.createObjectURL(file);
      else
        return null;
    },
    triggerUpload() {
      this.$refs.fileInput.click();
    },
    handleFileChange(event) {
      const file = event.target.files[0];
      if (file) {
        // handle your file upload logic here
        this.damageTech_cmt_payload.files.push(file);
      }
    },
    test() {
      if (this.Data.length == 0) {
        if (this.equipments_id == "") {
          swal(
            "warning !!",
            "Please can you chose equipment you use it!",
            "warning"
          );
          this.dialogValide = false;
          this.dialogValideDamage = false;
        } else {
          swal({
            title: "Click YES",
            text: "if you want validate your checklist !",
            buttons: true,
            dangerMode: false,
          }).then((willDelete) => {
            if (willDelete) {
              this.presenceCheck.user_id = this.getUserActive.id;
              this.presenceCheck.equipment_id = this.equipments_id;
              this.presenceChecksAction(this.presenceCheck).then((resolve) => {
                swal("success !!", "Checklist success", "success");
              });
              this.dialogValide = false;
              this.dialogValideDamage = false;
            } else {
              swal("Checklist cancel");
            }
          });
        }
      } else {
        this.dialogValideDamage = true;
      }
    },
    imagefullScreen(pic) {
      this.damageTech_cmt_fullscreen_img = true;
      this.cmt_actual_pic = pic;
    },
    techDefects_withCmt(item) {
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
      this.selected_sub_Defect = item;
      if (item.damageTech_cmt_payload) {
        this.damageTech_cmt_payload = {
          comment: "",
          files: []
        };
        if (item.name != "Other & comment") {
          this.damageTech_cmt_payload.comment = item.damageTech_cmt_payload.comment;
          this.damageTech_cmt_payload.files = item.damageTech_cmt_payload.files;
        }

      }
      else {

        this.damageTech_cmt_payload = {
          comment: "",
          files: []
        };
        item.damageTech_cmt_payload = this.damageTech_cmt_payload;
      }
      this.damageTech_cmt = true;

      //this.valider_2(item)
    },
    techDefects_withCmt_confirm() {
      let foundMasterDamage = null;
      console.log("this.selected_sub_Defect first ", this.selected_sub_Defect);
      this.selected_sub_Defect.damageTech_cmt_payload = this.damageTech_cmt_payload;
      if (this.selected_sub_Defect?.name == "Other & comment" && this.selected_sub_Defect.department_id == 1) {
        for (let index = 0; index < this.damageTypesIT.length; index++) {
          if (this.damageTypesIT[index].id == this.selected_sub_Defect?.damage_type_master.id) {
            foundMasterDamage = this.damageTypesIT[index];
            this.countMineId--;
            this.selected_sub_Defect = {
              "id": this.countMineId,
              "name": this.selected_sub_Defect?.damageTech_cmt_payload.comment,
              "important": 0,
              "profile_group_id": this.selected_sub_Defect?.profile_group_id,
              "department_id": this.selected_sub_Defect?.department_id,
              "created_at": "25\/05\/2025 11:12",
              "updated_at": "25\/05\/2025 11:12",
              "damage_type_id": this.selected_sub_Defect?.damageType_master.id,
              "icon": null,
              "damage": null,
              "damageType_master": this.selected_sub_Defect?.damageType_master,
              "profile_group": this.selected_sub_Defect?.profile_group,
              "department": this.selected_sub_Defect?.department,
              "damage_type_master": this.selected_sub_Defect?.damage_type_master,
              "damageTech_cmt_payload": this.selected_sub_Defect?.damageTech_cmt_payload,
              damage_master_id: this.selected_sub_Defect?.damageType_master.id,
            };
            this.damageTypesIT[index].damageTypes.push(
              this.selected_sub_Defect
            );
          }

        }
      }
      else if (this.selected_sub_Defect?.name == "Other & comment" && this.selected_sub_Defect.department_id == 2) {
        for (let index = 0; index < this.damageTypesTEC.length; index++) {
          if (this.damageTypesTEC[index].id == this.selected_sub_Defect?.damage_type_master.id) {
            foundMasterDamage = this.damageTypesTEC[index];
            this.countMineId--;
            this.selected_sub_Defect = {
              "id": this.countMineId,
              "name": this.selected_sub_Defect?.damageTech_cmt_payload.comment,
              "important": 0,
              "profile_group_id": this.selected_sub_Defect?.profile_group_id,
              "department_id": this.selected_sub_Defect?.department_id,
              "created_at": "25\/05\/2025 11:12",
              "updated_at": "25\/05\/2025 11:12",
              "damage_type_id": this.selected_sub_Defect?.damageType_master.id,
              "icon": null,
              "damage": null,
              "damageType_master": this.selected_sub_Defect?.damageType_master,
              "profile_group": this.selected_sub_Defect?.profile_group,
              "department": this.selected_sub_Defect?.department,
              "damage_type_master": this.selected_sub_Defect?.damage_type_master,
              "damageTech_cmt_payload": this.selected_sub_Defect?.damageTech_cmt_payload,
              damage_master_id: this.selected_sub_Defect?.damageType_master.id,
            };
            this.damageTypesTEC[index].damageTypes.push(
              this.selected_sub_Defect
            );
          }

        }
      }
      this.valider_2(this.selected_sub_Defect);
      this.damageTech_cmt = false;
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
      console.log("this.selected_sub_Defect ", this.selected_sub_Defect);
      console.log("foundMasterDamage ", foundMasterDamage);
      if (this.selected_sub_Defect?.damage_type_master.name == "OTHER" && foundMasterDamage?.damageTypes.length == 2) {
        console.log("dkhl.")
        this.valider_cmt_first_confirm();
      }
    },
    techDefects_withCmt_close() {
      this.damageTech_cmt = false;
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
    },
    changeProfile_groupeSELECT() {
      this.modelDamageIT = [];
      this.modelDamageTEC = [];
      this.equipmentsFiltre = [];
      this.confirmedDamageTEC = [];
      this.confirmedDamageIT = [];
      this.damageTypesIT.length = 0;
      this.damageTypesTEC.length = 0;
      this.equipments_id = 0;
      this.disabledEquipmentsFiltre = false;
      var count = 0;
      this.equipments.map((item) => {
        if (item.profile_group_id == this.profile_groupe_id) {
          this.equipmentsFiltre.push(item);
          count++;
        }
      });
      if (count == 0) {
        this.equipmentsFiltre = [];
      }
      setTimeout(()=>{
        this.openProfileGroupSelect_2();
      },0)
    },
    changeEquipmentsFiltreSELECT() {
      this.LoadingPage=true;
      var IT = this.departmentIT.id;
      var TEC = this.departmentTEC.id;
      this.modelDamageTEC = [];
      this.modelDamageIT = [];
      this.damageTypesTEC = [];
      this.damageTypesIT = [];
      this.modelTEC = [];
      this.modelIT = [];
      this.Data = [];
      this.confirmedDamageTEC = [];
      this.confirmedDamageIT = [];
      this.FindDamageTypeByEquipmentID = [];
      this.setequipmentsByIDAction(this.equipments_id).then(() => {
        this.EquipmentName = [this.getequipments];
      });
      this.getEquipmentDamagesMergedWithDamageTypesAction(
        this.equipments_id
      ).then(() => {
        this.DamagesMergedWithDamageTypes = [
          ...this.getEquipmentDamagesMergedWithDamageTypes,
        ];


        this.damageTypesTEC = this.DamagesMergedWithDamageTypes.filter(
          (c) => c.department_id == TEC
        );
        this.damageTypesTEC = this.damageTypesTEC.filter((u) => u.damage_type_id == null).map((e) => {
          e.isSelected = false;
          e.damageTech_cmt_payload = {
            comment: "",
            files: []
          }
          return e;
        });

        this.damageTypesIT = this.DamagesMergedWithDamageTypes.filter(
          (c) => c.department_id == IT
        );
        this.damageTypesIT = this.damageTypesIT.filter((u) => u.damage_type_id == null).map((e) => {
          if (e.name != "OTHER") {
            e.isSelected = false;
            return e;
          }
          else {
            e.isSelected = false;
            e.damageTech_cmt_payload = {
              comment: "",
              files: []
            }
            return e;
          }

        })

        this.countReset();
        this.LoadingPage=false;
      }).catch(()=>{
        this.LoadingPage=false;
      });

    },
    countReset() {
      this.countDefects = 0;
      this.countResolved = 0;
      this.countDefectsTEC = 0;
      this.countResolvedTEC = 0;
      this.countImportantTEC = 0;
      this.countImportantIT = 0;
      this.damageTypesIT.map((e) => {
        if (e.name != "OTHER") {
          if (e.damage == null) {
            if (this.Data.filter((b) => {
              return b.damage_type_id == e.id;
            }).length > 0) {
              this.countDefects = this.countDefects + 1;
              e.countDefective = e.countDefective + 1;
              if (e.important == true) {
                this.countImportantIT = this.countImportantIT + 1;
                e.countImportantDefective = e.countImportantDefective + 1;
              }

            }
          } else if (e.damage.status == "on progress" || this.Data.filter((b) => {
            return b.id == e.id;
          }).length > 0) {
            this.countDefects = this.countDefects + 1;
            if (e.important == true) {
              this.countImportantIT = this.countImportantIT + 1;
              e.countImportantDefective = e.countImportantDefective + 1;

            }
          } else if (e.damage.status == "resolved") {
            this.countResolved = this.countResolved + 1;
          }
        }
        else {
          e.countImportantDefective = 0;
          e.countDefective = 0;
          e.countResolved = 0;
          e.damageTypes.map((c) => {
            if (c.damage == null) {
              if (this.Data.filter((b) => {
                return b.damage_type_id == c.id;
              }).length > 0) {
                this.countDefects = this.countDefects + 1;
                e.countDefective = e.countDefective + 1;
                if (c.important == true) {
                  this.countImportantIT = this.countImportantIT + 1;
                  e.countImportantDefective = e.countImportantDefective + 1;
                }

              }
            } else if (c.damage.status == "on progress" || this.Data.filter((b) => {
              return b.id == c.id;
            }).length > 0) {
              this.countDefects = this.countDefects + 1;
              e.countDefective = e.countDefective + 1;
              if (c.important == true) {
                this.countImportantIT = this.countImportantIT + 1;
                e.countImportantDefective = e.countImportantDefective + 1;

              }
            } else if (c.damage.status == "resolved") {
              this.countResolved = this.countResolved + 1;
              e.countResolved = e.countResolved + 1;
            }

            return c;
          })
          return e;
        }


      });
      this.damageTypesTEC = this.damageTypesTEC.map((e) => {
        e.countImportantDefective = 0;
        e.countDefective = 0;
        e.countResolved = 0;
        e.damageTypes.map((c) => {
          if (c.damage == null) {
            if (this.Data.filter((b) => {
              return b.damage_type_id == c.id;
            }).length > 0) {
              this.countDefectsTEC = this.countDefectsTEC + 1;
              e.countDefective = e.countDefective + 1;
              if (c.important == true) {
                this.countImportantTEC = this.countImportantTEC + 1;
                e.countImportantDefective = e.countImportantDefective + 1;
              }

            }
          } else if (c.damage.status == "on progress" || this.Data.filter((b) => {
            return b.id == c.id;
          }).length > 0) {
            this.countDefectsTEC = this.countDefectsTEC + 1;
            e.countDefective = e.countDefective + 1;
            if (c.important == true) {
              this.countImportantTEC = this.countImportantTEC + 1;
              e.countImportantDefective = e.countImportantDefective + 1;
            }
          } else if (c.damage.status == "resolved") {
            this.countResolvedTEC = this.countResolvedTEC + 1;
            e.countResolved = e.countResolved + 1;
          }

          return c;
        })
        return e;
      });
    },
    initialize() {
      this.LoadingPage = true;
      this.setPROFILEDROUPSAction_by_user(this.getUserActive.id).then((response) => {

        console.log("response :", this.getprofilegroups);
        if (this.getprofilegroups == 0) {
          swal("warning !!", "You don't have any group !", "warning");
          this.disabled = true;
          // this.profile_groupe = [...this.getprofilegroups];
        } else {
          this.profile_groupe = [...this.getprofilegroups];
        }

        this.getprofilegroups.map((t) => {
          t.equipments.map((z) => {
            this.equipments.push(z);
          })
        })

        this.department = [...response.departments];
        this.department.map((item) => {
          if (item.name.toLowerCase() == "technique") {
            this.departmentTEC = item;
          }
          if (item.name.toLowerCase() == "it") {
            this.departmentIT = item;
          }
          if (item.name.toLowerCase() == "operations") {
            this.departmentOP = item;
          }
        });


        /*
        this.setUsersbyIDAction(this.getUserActive.id).then(() => {
          this.userFiltre = this.getUsers;
          if (this.userFiltre.profileGroups.length == 0) {
            swal("warning !!", "You don't have any group !", "warning");
            this.disabled = true;
            // this.profile_groupe = [...this.getprofilegroups];
          } else if (this.userFiltre.profileGroups.length != 0) {
            this.profile_groupe = [...this.userFiltre.profileGroups];
          }
        });
        */
        this.LoadingPage = false;
        this.openProfileGroupSelect();
      }).catch((r) => {
        this.LoadingPage = false;
      })
      /*
      this.setequipmentsAction().then(() => {
        this.equipments = [...this.getequipments];
      });
      this.setDepartementsAction().then(() => {
        this.department = [...this.getdepartements];
        this.department.map((item) => {
          if (item.name.toLowerCase() == "technique") {
            this.departmentTEC = item;
          }
          if (item.name.toLowerCase() == "it") {
            this.departmentIT = item;
          }
          if (item.name.toLowerCase() == "operations") {
            this.departmentOP = item;
          }
        });
      });
      */
    },
    ...mapActions([
      "setDAMAGEAction",
      "editDAMAGEAction",
      "deleteDAMAGEAction",
      "declareDamageAction",
      "confirmDamageAction",
      "closeDamageAction",
      "revertDamageAction",
      "revertDamageAction_2",
      "setDAMAGETYPESAction",
      "setPROFILEDROUPSAction",
      "setequipmentsAction",
      "addDAMAGESAction",
      "FindDamageTypeByEquipmentIDAction",
      "getEquipmentDamagesMergedWithDamageTypesAction",
      "setDepartementsAction",
      "setUsersbyIDAction",
      "presenceChecksAction",
      "setequipmentsByIDAction",
      "SendEmailAction",
      "closeDamageAction_2",
      "setPROFILEDROUPSAction_by_user",
    ]),
    isChecked(item) {
      let isCheck = false;
      this.Data.map((e) => {
        if (item.id == e.damage_type_id)
          isCheck = true;
      });
      this.Data_2.map((e) => {
        if (item.id == e.damage_type_id)
          isCheck = true;
      });
      return isCheck;
    },
    MasterIsChecked(item) {
      if (item.damage == true)
        return true;
      let isCheck = false;
      item.damageTypes.map((t) => {
        this.Data.map((e) => {
          if (t.id == e.damage_type_id)
            isCheck = true;
        });
      });


      return isCheck;
    },
    valider_cmt_first(item, i) {
      console.log("item :", item)
      if (item.name == "OTHER") {
        if (item.damageTypes.length == 1) {
          item.isSelected = true;
          this.damageTech_cmt_payload = item.damageTech_cmt_payload;
          this.selectedDefect = item;
          this.defectList = item.damageTypes;
          this.techDefects_withCmt(item.damageTypes[0]);
          return;
        }
      }
      this.driver_comment_dialog = true;

      item.isSelected = true;
      this.damageTech_cmt_payload = item.damageTech_cmt_payload;
      this.selectedDefect = item;
      this.defectList = item.damageTypes;
    },
    valider_cmt_first_confirm() {
      this.driver_comment_dialog = false;
      this.damageTypesTEC = this.damageTypesTEC.map((e) => {
        if (e.id == this.selectedDefect.id) {
          e.isSelected = false
        }
        return e;
      });
      this.selectedDefect = null;
      this.Data_2.map((e) => {
        this.Data.push(e);

      });

      this.Data_2 = [];
      this.countReset();
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
    },
    valider_cmt_first_cancel() {
      this.driver_comment_dialog = false;



      this.damageTypesIT = this.damageTypesIT.map((e) => {
        if (e.id == this.selectedDefect.id) {
          e.isSelected = false
        }
        return e;
      })


      this.damageTypesTEC = this.damageTypesTEC.map((e) => {
        if (e.id == this.selectedDefect.id) {
          e.isSelected = false
        }
        return e;
      })
      this.Data_2 = [];
      this.selectedDefect = null;
    },
    valider(item, i) {
      this.damageCourent.declaredBy_id = this.getUserActive.id;
      this.damageCourent.damage_type_id = item.id;
      this.damageCourent.equipment_id = this.equipments_id;
      this.damage_type_id = item.id;
      this.modelIT_id_Courent = i;

      if (item.department.name == "IT") {
        this.listdepartmentIT.push(item.department.name);
        this.listDefectsNamesIT.push(item);
      } else if (item.department.name == "TECHNIQUE") {
        this.listdepartmentTEC.push(item.department.name);
        this.listDefectsNamesTEC.push(item);
      }

      if (this.Data.length == 0) {
        if (item.important == true) {
          swal(
            "warning !",
            "this item " +
            `*** ${item.name} *** ` +
            " must be immediately reported to the hierarchy ",
            "warning"
          );
          var Damage = {
            declaredBy_id: null,
            equipment_id: null,
            damage_type_id: null,
            department_id: null,
            damage_master_id: null,
            shift: "",
          };
          Damage.declaredBy_id = this.getUserActive.id;
          Damage.damage_type_id = this.damage_type_id;
          Damage.equipment_id = this.equipments_id;
          Damage.shift = this.getActualShift();
          Damage.department_id = item.department_id;
          Damage.damage_master_id = item.damage_master_id,
            this.damageSelect.push(Damage);
          this.Data.push(Damage);
        } else {
          var Damage = {
            declaredBy_id: null,
            equipment_id: null,
            damage_type_id: null,
            department_id: null,
            damage_master_id: null,
            shift: "",
          };
          Damage.declaredBy_id = this.getUserActive.id;
          Damage.damage_type_id = this.damage_type_id;
          Damage.equipment_id = this.equipments_id;
          Damage.department_id = item.department_id;
          Damage.damage_master_id = item.damage_master_id,
            Damage.shift = this.getActualShift();

          this.damageSelect.push(Damage);

          this.Data.push(Damage);
        }
      } else if (this.Data.length > 0) {
        this.isvalide = false;
        this.Data.map((e) => {
          if (e.damage_type_id == this.damage_type_id) {
            this.isvalide = true;
          }
        });
        if (this.isvalide == true) {
          this.Data = this.Data.filter((c) => c.damage_type_id != item.id);
        } else {
          if (item.important == true) {
            swal(
              "warning !",
              `*** ${item.name} *** ` +
              " must be immediately reported to the hierarchy ",
              "warning"
            );
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              damage_master_id: null,
              shift: "",
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.damage_master_id = item.damage_master_id,
              Damage.shift = this.getActualShift();

            this.damageSelect.push(Damage);

            this.Data.push(Damage);
          } else {
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              damage_master_id: null,
              shift: "",
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.shift = this.getActualShift();
            Damage.damage_master_id = item.damage_master_id,
              this.damageSelect.push(Damage);

            this.Data.push(Damage);
          }
        }
      }
      this.countReset();
    },
    valider_2(item) {

      this.damageCourent.declaredBy_id = this.getUserActive.id;
      this.damageCourent.damage_type_id = item.id;
      this.damageCourent.equipment_id = this.equipments_id;
      this.damage_type_id = item.id;

      if (item.department.name == "IT") {
        this.listdepartmentIT.push(item.department.name);
        this.listDefectsNamesIT.push(item);
      } else if (item.department.name == "TECHNIQUE") {
        this.listdepartmentTEC.push(item.department.name);
        this.listDefectsNamesTEC.push(item);
      }



      if (this.Data.length > 0) {
        this.isvalide = false;
        this.Data.map((e) => {
          if (e.damage_type_id == this.damage_type_id) {
            this.isvalide = true;
          }
        });
        if (this.isvalide == true) {
          this.Data = this.Data.filter((c) => c.damage_type_id != item.id);

        }
      }







      if (this.Data_2.length == 0) {
        if (item.important == true) {
          swal(
            "warning !",
            "this item " +
            `*** ${item.name} *** ` +
            " must be immediately reported to the hierarchy ",
            "warning"
          );
          var Damage = {
            declaredBy_id: null,
            equipment_id: null,
            damage_type_id: null,
            department_id: null,
            shift: "",
            damage_master_id: null,
            damageTech_cmt_payload: {
              comment: "",
              files: []
            }
          };
          Damage.declaredBy_id = this.getUserActive.id;
          Damage.damage_type_id = this.damage_type_id;
          Damage.equipment_id = this.equipments_id;
          Damage.department_id = item.department_id;
          Damage.shift = this.getActualShift();
          Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
          Damage.damage_master_id = item.damage_master_id,
            this.damageSelect.push(Damage);

          this.Data_2.push(Damage);
        } else {
          var Damage = {
            declaredBy_id: null,
            equipment_id: null,
            damage_type_id: null,
            department_id: null,
            shift: "",
            damage_master_id: null,
            damageTech_cmt_payload: {
              comment: "",
              files: []
            }
          };
          Damage.declaredBy_id = this.getUserActive.id;
          Damage.damage_type_id = this.damage_type_id;
          Damage.equipment_id = this.equipments_id;
          Damage.department_id = item.department_id;
          Damage.shift = this.getActualShift();
          Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
          Damage.damage_master_id = item.damage_master_id,
            this.damageSelect.push(Damage);

          this.Data_2.push(Damage);
        }
      } else if (this.Data_2.length > 0) {
        this.isvalide = false;
        this.Data_2.map((e) => {
          if (e.damage_type_id == this.damage_type_id) {
            this.isvalide = true;
          }
        });
        if (this.isvalide == true) {
          this.Data_2 = this.Data_2.filter((c) => c.damage_type_id != item.id);
          if (item.important == true) {
            swal(
              "warning !",
              `*** ${item.name} *** ` +
              " must be immediately reported to the hierarchy ",
              "warning"
            );
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              shift: "",
              damage_master_id: null,
              damageTech_cmt_payload: {
                comment: "",
                files: []
              }
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.shift = this.getActualShift();
            Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
            Damage.damage_master_id = item.damage_master_id,
              this.damageSelect.push(Damage);

            this.Data_2.push(Damage);
          } else {
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              shift: "",
              damageTech_cmt_payload: {
                comment: "",
                files: []
              },
              damage_master_id: null,
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.shift = this.getActualShift();
            this.damageSelect.push(Damage);
            Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
            Damage.damage_master_id = item.damage_master_id,
              this.Data_2.push(Damage);
          }
        } else {
          if (item.important == true) {
            swal(
              "warning !",
              `*** ${item.name} *** ` +
              " must be immediately reported to the hierarchy ",
              "warning"
            );
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              shift: "",
              damageTech_cmt_payload: {
                comment: "",
                files: []
              }
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.shift = this.getActualShift();
            Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
            Damage.damage_master_id = item.damage_master_id,
              this.damageSelect.push(Damage);

            this.Data_2.push(Damage);
          } else {
            var Damage = {
              declaredBy_id: null,
              equipment_id: null,
              damage_type_id: null,
              department_id: null,
              shift: "",
              damageTech_cmt_payload: {
                comment: "",
                files: []
              },
              damage_master_id: null,
            };
            Damage.declaredBy_id = this.getUserActive.id;
            Damage.damage_type_id = this.damage_type_id;
            Damage.equipment_id = this.equipments_id;
            Damage.department_id = item.department_id;
            Damage.shift = this.getActualShift();
            Damage.damage_master_id = item.damage_master_id,
              this.damageSelect.push(Damage);
            Damage.damageTech_cmt_payload = item.damageTech_cmt_payload;
            this.Data_2.push(Damage);
          }
        }
      }


    },
    valider_3(item) {

      this.damageCourent.declaredBy_id = this.getUserActive.id;
      this.damageCourent.damage_type_id = item.id;
      this.damageCourent.equipment_id = this.equipments_id;
      this.damage_type_id = item.id;

      if (item.department.name == "IT") {
        this.listdepartmentIT.push(item.department.name);
        this.listDefectsNamesIT.push(item);
      } else if (item.department.name == "TECHNIQUE") {
        this.listdepartmentTEC.push(item.department.name);
        this.listDefectsNamesTEC.push(item);
      }



      if (this.Data.length > 0) {
        this.isvalide = false;
        this.Data.map((e) => {
          if (e.damage_type_id == item.id) {
            this.isvalide = true;
          }
        });
        if (this.isvalide == true) {
          this.Data = this.Data.filter((c) => c.damage_type_id != item.id);

        }
      }
      if (this.Data_2.length > 0) {
        this.isvalide = false;
        this.Data_2.map((e) => {
          if (e.damage_type_id == item.id) {
            this.isvalide = true;
          }
        });
        if (this.isvalide == true) {
          this.Data_2 = this.Data_2.filter((c) => c.damage_type_id != item.id);

        }
      }

      if (this.selectedDefect?.damageTypes.length == 1
        && this.selected_sub_Defect?.damage_type_master.name == 'OTHER') {
        this.valider_cmt_first_confirm();

        this.damageTech_cmt = false;

      }







    },
    resolvedFunction(item) {
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
      this.resolveditem = [];
      this.resolvedDialoge = true;
      this.resolveditem.push(item);
    },
    defectedFunction(item) {
      this.damageTech_cmt_payload = {
        comment: "",
        files: []
      };
      this.resolveditem = [];
      this.defectedDialoge = true;
      this.resolveditem.push(item);
    },
    changeDefectsFunction() {
      this.defectsChange.item = this.resolveditem[0];
      this.defectsChange.damagetypeOld = this.resolveditem[0].damage;
      this.defectsChange.statusOld = this.resolveditem[0].damage.status;
      this.defectsChange.statusNew = "closed";

      this.listDefectsChange.push(this.defectsChange);
      if (this.resolveditem[0].department.name == "IT") {
        this.damageTypesIT.push(this.resolveditem[0]);
        this.modelDamageIT = this.modelDamageIT.filter(
          (c) => c.id != this.resolveditem[0].id
        );
      } else if (this.resolveditem[0].department.name == "TECHNIQUE") {
        this.damageTypesTEC.push(this.resolveditem[0]);
        this.modelDamageTEC = this.modelDamageTEC.filter(
          (c) => c.id != this.resolveditem[0].id
        );
      }
      this.defectedDialoge = false;
    },
    confirmed() {
      this.LoadingPage = true;
      this.closeDamage.id = this.resolveditem[0].damage.id;
      this.closeDamage.closedBy_id = this.getUserActive.id;
      let formData = new FormData();
      formData.append(`damages[id]`, this.closeDamage.id);
      formData.append(`damages[closedBy_id]`, this.closeDamage.closedBy_id);
      formData.append(`damages[damageTech_cmt_payload][comment]`, this.damageTech_cmt_payload.comment);
      this.damageTech_cmt_payload.files.forEach((picFile, picIndex) => {
        formData.append(`damages[damageTech_cmt_payload][files][${picIndex}]`, picFile);
      });
      if (this.closeDamage.id < 0) {
        console.log("this.closeDamage :", this.closeDamage);
        console.log("this.resolveditem[0] :", this.resolveditem[0]);
      }
      this.closeDamageAction_2(formData)
        .then((resolve) => {
          this.damageTech_cmt_payload = {
            comment: "",
            files: []
          };
          this.defectedDialoge = false;
          this.modelTEC = [];
          this.modelIT = [];
          this.defectedDialoge = false;
          this.resolvedDialoge = false;
          this.damageTypesTEC = this.damageTypesTEC.map((e) => {
            let isChecked = false;
            e.damageTypes = e.damageTypes.map((c) => {
              if (c.id == this.resolveditem[0].id) {
                c.damage = null;
              }

              if (c.damage != null)
                isChecked = true;

              return c;
            });
            e.damage = isChecked;
            return e;
          });
          console.log("dkhl.",this.damageTypesIT)
          console.log("this.resolveditem[0].",this.resolveditem[0])
          this.damageTypesIT = this.damageTypesIT.map((e) => {
            if (e.name != "OTHER") {
              let isChecked = false;
              if (e.id == this.resolveditem[0].id) {
                e.damage = null;
              }
              return e;
            }
            else {
              let isChecked = false;
              e.damageTypes = e.damageTypes.map((c) => {
                if (c.id == this.resolveditem[0].id) {
                  c.damage = null;
                }

                if (c.damage != null)
                  isChecked = true;

                return c;
              });
              e.damage = isChecked;
              return e;
            }

          });
          console.log("dkhl.",this.damageTypesIT)
          this.countReset();
          console.log("daz.")
          if (this.resolveditem[0]?.department_id!=1 && this.resolveditem[0]?.damage_type_master.name == "OTHER") {
            console.log("dkhl.")
            this.valider_cmt_first_confirm();
          }
          this.resolveditem = [];
          this.LoadingPage = false;
          swal("Good job!", "success", "success");

          //this.$router.go();
        })
        .catch(() => {
          swal("Error", "", "error");
        });

    },
    closed() {
      this.closeDamage.id = this.resolveditem[0].damage.id;
      this.closeDamage.closedBy_id = this.getUserActive.id;
      this.closeDamageAction_2(this.closeDamage)
        .then((resolve) => {
          //this.EmailModel.payload.Equipment = this.EquipmentName[0].name;
          //this.EmailModel.status = "Closed ";
          //
          //this.EmailModel.payload.EquipmentGroupe =
          //  this.resolveditem[0].department.name;
          //this.EmailModel.payload.Defects = resolve.damage_type.name;
          //this.EmailModel.payload.Status = "closed";
          //this.EmailModel.email =
          //  this.departmentOP.email.toString() +
          //  this.resolveditem[0].department.email.toString();
          //
          //this.EmailModel.payload.ClosedBy = this.getUserActive.username;
          //this.EmailModel.payload.ClosedAt = resolve.declaredAt;
          //if (resolve.driver_out != null) {
          //  this.EmailModel.payload.DriverOut = resolve.driver_out.username;
          //} else {
          //}
          //this.EmailModel.payload.DeclaredBy = resolve.declared_by.username;
          //this.EmailModel.payload.DeclaredAt = resolve.declaredAt;
          //
          //this.SendEmailAction(this.EmailModel).then(() => {
          //});
          this.resolvedDialoge = false;
          // this.LoadingPage = true;

          this.$router.go();
        })
        .catch(() => {
          swal("Error", "", "error");
        });

      this.changeEquipmentsFiltreSELECT();
      this.modelTEC = [];
      this.modelIT = [];
    },
    revert() {
      this.LoadingPage = true;
      this.revertDamage.id = this.resolveditem[0].damage.id;
      this.revertDamage.rejectedBy_id = this.getUserActive.id;
      let formData = new FormData();
      formData.append(`damages[id]`, this.revertDamage.id);
      formData.append(`damages[rejectedBy_id]`, this.revertDamage.rejectedBy_id);
      formData.append(`damages[damageTech_cmt_payload][comment]`, this.damageTech_cmt_payload.comment);
      this.damageTech_cmt_payload.files.forEach((picFile, picIndex) => {
        formData.append(`damages[damageTech_cmt_payload][files][${picIndex}]`, picFile);
      });


      this.revertDamageAction_2(formData)
        .then((resolve) => {
          //this.EmailModel.payload.Equipment = this.EquipmentName[0].name;
          //this.EmailModel.payload.EquipmentGroupe =
          //  this.resolveditem[0].department.name;
          //this.EmailModel.payload.Defects = resolve.damage_type.name;
          //this.EmailModel.status = "Rejcted ";
          //this.EmailModel.email =
          //  this.departmentOP.email.toString() +
          //  this.resolveditem[0].department.email.toString();
          //
          //this.EmailModel.payload.Status = "on progress";
          //this.EmailModel.payload.Rejected_by = this.getUserActive.username;
          //this.EmailModel.payload.RejectedAt = resolve.declaredAt;
          //this.EmailModel.payload.RejectedTimes = resolve.rejectedTimes;
          //this.EmailModel.payload.Confirmed_by = resolve.confirmed_by.username;
          //this.EmailModel.payload.ConfirmedAt = resolve.declaredAt;
          //
          //if (resolve.driver_out != null) {
          //  this.EmailModel.payload.DriverOut = resolve.driver_out.username;
          //} else {
          //}
          //this.EmailModel.payload.DeclaredBy = resolve.declared_by.username;
          //this.EmailModel.payload.declaredAt = resolve.declaredAt;
          //
          //this.SendEmailAction(this.EmailModel).then(() => {
          //});
          this.damageTech_cmt_payload = {
            comment: "",
            files: []
          };

          this.defectedDialoge = false;
          this.modelTEC = [];
          this.modelIT = [];
          this.resolvedDialoge = false;
          this.damageTypesTEC = this.damageTypesTEC.map((e) => {
            let isChecked = false;
            e.damageTypes = e.damageTypes.map((c) => {
              if (c.id == this.resolveditem[0].id) {
                c.damage = resolve;
              }

              if (c.damage != null)
                isChecked = true;

              return c;
            });
            e.damage = isChecked;
            return e;
          });

          this.damageTypesIT = this.damageTypesIT.map((e) => {
            if (e.name != "OTHER") {
              let isChecked = false;
              if (e.id == this.resolveditem[0].id) {
                e.damage = resolve;
              }
              return e;
            }
            else {
              let isChecked = false;
              e.damageTypes = e.damageTypes.map((c) => {
                if (c.id == this.resolveditem[0].id) {
                  c.damage = resolve;
                }

                if (c.damage != null)
                  isChecked = true;

                return c;
              });
              e.damage = isChecked;
              return e;
            }

          });

          this.countReset();
          if (this.resolveditem[0]?.department_id!=1 && this.resolveditem[0]?.damage_type_master.name == "OTHER") {
            console.log("dkhl.")
            this.valider_cmt_first_confirm();
          }





          this.resolvedDialoge = false;

          this.LoadingPage = false;

          //this.$router.go();
        })
        .catch(() => {
          swal("Error", "", "error");
        });


    },
    cancel() {
      this.dialog = false;
    },
    cancelvalide() {
      if (this.Data.length == 0) {
        this.dialogValide = false;
      } else {
        this.Data = this.Data.map((e) => {
          if (e.damage_type_id != this.damage_type_id) {
            return e;
          }
        });
        this.dialogValide = false;
        this.modelIT = this.modelIT.map((e) => {
          if (e != this.modelIT_id_Courent) {
            return e;
          }
        });
        this.Data = this.Data.filter(function (element) {
          return element !== undefined;
        });
      }
    },
    dialogValideFunction(item, i) {
      this.damageCourent.declaredBy_id = this.getUserActive.id;
      this.damageCourent.damage_type_id = item.id;
      this.damageCourent.equipment_id = this.equipments_id;
      this.damage_type_id = item.id;
      this.modelIT_id_Courent = i;
      //this.dialogValide = true;
    },
    clearModelEmail() {
      this.EmailModel.payload = {
        Equipment: "",
        EquipmentGroupe: "",
        Department: "",
        Defects: [],
        Status: "on progress",
        DriverOut: "",
        DeclaredBy: "",
        DeclaredAt: "",
      };
      this.EmailModel.status = "";
      this.EmailModel.email = "";
      this.EmailModel.department = [];

      // TEC

      this.EmailModelTEC.payload = {
        Equipment: "",
        EquipmentGroupe: "",
        Department: "",
        Defects: [],
        Status: "on progress",
        DriverOut: "",
        DeclaredBy: "",
        DeclaredAt: "",
      };
      this.EmailModelTEC.status = "";
      this.EmailModelTEC.email = "";
      this.EmailModelTEC.department = [];

      this.listdepartmentIT = [];
      this.listdepartmentIT = [];
      this.listDefectsNamesIT = [];
      this.listDefectsNamesITFinal = [];

      this.listdepartmentTEC = [];
      this.listdepartmentTEC = [];
      this.listDefectsNamesTEC = [];
      this.listDefectsNamesTECFinal = [];
    },
    validerDamages() {
      console.log("this.Data :", this.Data);
      this.LoadingPage = true;
      let formData = new FormData();
      this.Data.forEach((item, index) => {
        formData.append(`damages[${index}][declaredBy_id]`, item.declaredBy_id);
        formData.append(`damages[${index}][equipment_id]`, item.equipment_id);
        formData.append(`damages[${index}][damage_type_id]`, item.damage_type_id);
        formData.append(`damages[${index}][damage_master_id]`, item.damage_master_id);
        formData.append(`damages[${index}][shift]`, item.shift);
        console.log("item lààà", item);
        console.log("this.damageTypesIT :", this.damageTypesIT);
        if (item.department_id == 2 || this.damageTypesIT?.filter((l) => l?.damageTypes.filter((o) => o.damageType_master.id == item.damage_master_id).length > 0).length > 0) {
          formData.append(`damages[${index}][damageTech_cmt_payload][comment]`, item.damageTech_cmt_payload.comment);

          item.damageTech_cmt_payload.files.forEach((picFile, picIndex) => {
            formData.append(`damages[${index}][damageTech_cmt_payload][files][${picIndex}]`, picFile);
          });
        } else {

          formData.append(`damages[${index}][damageTech_cmt_payload][comment]`, this.damageTech_cmt_payload.comment);

          this.damageTech_cmt_payload.files.forEach((picFile, picIndex) => {
            formData.append(`damages[${index}][damageTech_cmt_payload][files][${picIndex}]`, picFile);
          });
        }

      });
      if (this.Data.length == 0) {
        if (this.equipments_id == "") {
          swal(
            "warning !!",
            "Please can you chose equipment you use it!",
            "warning"
          );
          this.dialogValide = false;
          this.dialogValideDamage = false;
        } else {
          this.presenceCheck.user_id = this.getUserActive.id;
          this.presenceCheck.equipment_id = this.equipments_id;
          this.presenceChecksAction(this.presenceCheck)
            .then((resolve) => {
              swal("success !!", "", "success");
            })
            .catch(() => {
              swal("Error", "", "error");
            });

          this.dialogValide = false;
          this.dialogValideDamage = false;
        }
      } else if (this.Data.length > 0) {
        this.declareDamageAction(formData)
          .then((resolve) => {
            this.modelTEC = [];
            this.modelIT = [];
            this.EmailModel.payload.Defects = [];
            this.EmailModelTEC.payload.Defects = [];
            var ITemail = this.departmentIT.email;
            var TECemail = this.departmentTEC.email;

            this.Data.map((item) => {
              this.a = [...new Set(this.listDefectsNamesTEC)];

              this.a.map((c) => {
                if (c.id == item.damage_type_id) {
                  this.EmailModelTEC.payload.Defects.push(c.name);
                }
              });
            });
            this.Data.map((item) => {
              this.b = [...new Set(this.listDefectsNamesIT)];

              this.b.map((c) => {
                if (c.id == item.damage_type_id) {
                  this.EmailModel.payload.Defects.push(c.name);
                }
              });
            });

            if (this.listdepartmentIT.length != 0) {
              this.EmailModel.department = "IT";
              this.EmailModel.payload.Equipment = this.EquipmentName[0].name;
              this.EmailModel.payload.EquipmentGroupe =
                this.EquipmentName[0].profile_group.name;

              this.EmailModel.payload.Department = "IT";
              this.EmailModel.payload.Status = "on progress";
              this.EmailModel.status = "Defective ";
              this.EmailModel.email =
                this.departmentIT.email.toString() +
                this.departmentOP.email.toString();

              if (resolve[0].driver_out != null) {
                this.EmailModel.payload.DriverOut =
                  resolve[0].driver_out.username;
              } else {
              }
              this.EmailModel.payload.DeclaredBy =
                resolve[0].declaredBy.username;
              this.EmailModel.payload.DeclaredAt = resolve[0].declaredAt;
              this.SendEmailAction(this.EmailModel).then(() => {
                this.listdepartmentIT = [];
                this.listdepartmentIT = [];
                this.listDefectsNamesIT = [];
                this.listDefectsNamesITFinal = [];
              });
            }
            if (this.listdepartmentTEC.length != 0) {
              setTimeout(() => {
                this.EmailModelTEC.department = "TECHNIQUE";
                this.EmailModelTEC.payload.Equipment =
                  this.EquipmentName[0].name;
                this.EmailModelTEC.payload.EquipmentGroupe =
                  this.EquipmentName[0].profile_group.name;

                this.EmailModelTEC.payload.Department = "TECHNIQUE";
                this.EmailModelTEC.payload.Status = "on progress";
                this.EmailModelTEC.status = "Defective ";
                this.EmailModelTEC.email =
                  this.departmentTEC.email.toString() +
                  "," +
                  this.departmentOP.email.toString();
                if (resolve[0].driver_out != null) {
                  this.EmailModelTEC.payload.DriverOut =
                    resolve[0].driver_out.username;
                } else {
                }
                this.EmailModelTEC.payload.DeclaredBy =
                  resolve[0].declaredBy.username;
                this.EmailModelTEC.payload.DeclaredAt = resolve[0].declaredAt;


                this.SendEmailAction(this.EmailModelTEC).then(() => {

                  this.listdepartmentTEC = [];
                  this.listDefectsNamesTEC = [];
                  this.listDefectsNamesTECFinal = [];
                });
              }, 1000);
            }
            this.Data = [];
            this.Data_2 = [];
            this.presenceCheck.user_id = this.getUserActive.id;
            this.presenceCheck.equipment_id = this.equipments_id;
            this.presenceChecksAction(this.presenceCheck).then((resolve) => {
            });
            this.damageSelect = [];
            this.changeEquipmentsFiltreSELECT();
            this.dialogValide = false;
            this.dialogValideDamage = false;
            this.LoadingPage = true;
            this.LoadingPage = false;
            setTimeout(() => {
              this.LoadingPage = false;
              swal("Good job!", "success", "success");
            }, 1500);
          })
          .catch(() => {
            swal("Error", "", "error");
          });
      }
    },
    getActualShift() {
      let thisDate = new Date("2022-02-16T06:30:00");
      let nowDate = new Date();
      let shift = ["D", "A", "B", "C"];
      let momentDate = moment(thisDate);

      while (momentDate.add(72, "hours").toDate() < nowDate) {
        shift = this.shiftArrays(shift);
      }

      if (
        ((nowDate.getHours() == 6 && nowDate.getMinutes() >= 30) ||
          nowDate.getHours() >= 7) &&
        ((nowDate.getHours() == 14 && nowDate.getMinutes() < 30) ||
          nowDate.getHours() < 15)
      )
        return shift[0];
      else if (
        ((nowDate.getHours() == 14 && nowDate.getMinutes() >= 30) ||
          nowDate.getHours() >= 15) &&
        ((nowDate.getHours() == 22 && nowDate.getMinutes() < 30) ||
          nowDate.getHours() < 23)
      )
        return shift[1];
      else if (
        (nowDate.getHours() == 22 && nowDate.getMinutes() >= 30) ||
        (nowDate.getHours() >= 0 &&
          nowDate.getHours() < 6 &&
          nowDate.getMinutes() < 30)
      )
        return shift[2];
    },
    shiftArrays(array) {
      let c = "";
      c = array[3];
      array[3] = array[2];
      array[2] = array[1];
      array[1] = array[0];
      array[0] = c;

      return array;
    },
  },
};
</script>
